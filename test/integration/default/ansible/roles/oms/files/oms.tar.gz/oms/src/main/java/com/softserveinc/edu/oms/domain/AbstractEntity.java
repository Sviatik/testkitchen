package com.softserveinc.edu.oms.domain;

public abstract class AbstractEntity {
	public abstract Integer getId();

	public abstract void setId(final Integer id);
}
