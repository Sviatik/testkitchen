/**
 * 
 */
package com.softserveinc.edu.oms.web.pageablecontroler.util;

/**
 * @author Vitalik
 *
 */
public enum PageJspType {
	JspWithAjax,JspWithoutAjax,JspForCurrentPage;
}
