/**
 * 
 */
package com.softserveinc.edu.oms.web.pageablecontroler.util;

/**
 * @author Vitalik
 *
 */
public class PageableParameters {
	public static final String PAGE = "page";
	public static final String SHOW_ELEMENTS = "showElements";
	public static final String CONTROLER_WITHOUT_AJAX_URL = "controlerWithoutAjaxUrl";
}
